module.exports = {
  printWidth: 100,
  parser: 'typescript',
  singleQuote: true,
  trailingComma: true,
};
